//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MeshTestbed.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MESHTETYPE                  129
#define IDD_DIALOG_DEMOINFO             130
#define IDR_VIEWTOOL                    131
#define IDC_EDIT1                       1000
#define IDC_EDIT_VERTNUM                1000
#define IDC_CHECK1                      1001
#define IDC_CHECK2                      1002
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define IDC_RADIO3                      1005
#define IDC_EDIT2                       1006
#define IDC_EDIT_TRINUM                 1006
#define IDC_EDIT_EXTX                   1007
#define IDC_EDIT_EXTY                   1008
#define IDC_EDIT_EXTZ                   1009
#define IDC_EDIT_HANDLENUM              1010
#define IDC_EDIT_B2X                    1011
#define IDC_EDIT_B2Y                    1012
#define IDC_EDIT_B2Z                    1013
#define IDC_EDIT_B3X                    1014
#define IDC_EDIT_B3Y                    1015
#define IDC_EDIT_B3Z                    1016
#define ID_FILE_OPENSTL                 32771
#define ID_VIEW_ISO                     32772
#define ID_BUTTON32773                  32773
#define ID_VIEW_FRONT                   32774
#define ID_BUTTON32775                  32775
#define ID_VIEW_RIGHT                   32776
#define ID_BUTTON32777                  32777
#define ID_VIEW_PAN                     32778
#define ID_BUTTON32779                  32779
#define ID_VIEW_ZOOMIN                  32780
#define ID_VIEW_ZOOMOUT                 32781
#define ID_VIEW_ZOOMWINDOW              32782
#define ID_VIEW_SHADE                   32783
#define ID_VIEW_WIREFRAMESHADE          32784
#define ID_VIEW_WIREFRAME               32785
#define ID_VIEW_POINT                   32786
#define ID_VIEW_EXTENT                  32788
#define ID_VIEW_TOP                     32789
#define ID_CAMERA_ROTATE                32790
#define ID_VIEW_ZOOMALL                 32791
#define ID_VIEW_WIREFRAMESHADED         32792
#define ID_FILE_OPENSTL1                32793
#define ID_FILE_OPENSTL2                32794
#define ID_FILE_OPENSTL3                32795
#define ID_VIEW_WIREFRAMENOFLAT         32796
#define ID_BUTTON32797                  32797
#define ID_FILE_ASSEMBLESTLS            32797
#define ID_FILE_GENERATEBEZIER          32798
#define ID_FILE_GENERATEBEZIERSURF      32799

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
